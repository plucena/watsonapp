
/* JavaScript content from js/watson.js in folder common */
$( "#searchbtn" ).click(function() {
  alert( "Handler for .click() called." );
});